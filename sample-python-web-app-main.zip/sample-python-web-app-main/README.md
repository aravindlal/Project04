## Sample Python App

This is a basic Python application, used in a number of AWS tutorials, that focus on various ways to deploy it. It is a simple application that allows the user to sign up for a new startup.

## Security

See [CONTRIBUTING](CONTRIBUTING.md#security-issue-notifications) for more information.

## License

This library is licensed under the MIT-0 License. See the LICENSE file.
